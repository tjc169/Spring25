import math


def circle(a):
    pi = 3.14
    return a ** 2 * pi


def rect(a, b):
    return a * b


def square(a):
    return a ** 2
