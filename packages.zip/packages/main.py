from math_operations import geometry

result = geometry.circle(15)
print("Result:", result)
